.---------------------------------------------------------------------------.
|  Software: WhoisUP - Is your host up or down?                             |
|  Version: 0.3                                                             |
|  Site: http://whoisup.sourceforge.net/                                    |
| --------------------------------------------------------------------------|
|  Authors: Fabio Semperboni                                                |
|  Blog: http://www.ciscozine.com                                           |
|  Twitter: https://twitter.com/ciscozine                                   |
|  Copyright (c) 2012-2014, Fabio Semperboni                                |
| ------------------------------------------------------------------------- |
|  License: WhoisUP is released under the GPL                               |
|  This program is free software; you can redistribute it and/or modify     |
|  it under the terms of the GNU General Public License as published by     |
|  the Free Software Foundation; either version 2 of the License, or        |
|  (at your option) any later version.                                      |
|                                                                           |
|  This program is distributed in the hope that it will be useful,          |
|  but WITHOUT ANY WARRANTY; without even the implied warranty of           |
|  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
|  GNU General Public License for more details.                             |
|                                                                           |
|  You should have received a copy of the GNU General Public License        |
|  along with this program; if not, write to the Free Software              |
|  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA02110-1301  USA |
'---------------------------------------------------------------------------'


WHAT
WhoisUP monitors hosts via ICMP and shows the status in a web page.
When a host is down, the script can send mail, syslog message, open
a popup message or play a sound. 


WHEN
WhoisUP is useful to monitor hosts (PC, Server, NAS, Router,
Switch and so on...) and to receive alerts when a host go down. 


HOW
The script uses NMap to send ICMP packets and to save the host status
into an XML file. Then, WhoisUP reads the XML and shows the result in
a web page with AJAX features; in case of host failure the script can
send messages.


OPERATING SYSTEM
The script is not OS dependent; it works on Windows, Linux, ... without problem.