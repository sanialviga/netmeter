<?php
/*
.---------------------------------------------------------------------------.
|  Software: WhoisUP - Is your host up or down?                             |
|  Version: 0.3                                                             |
|  Site: http://whoisup.sourceforge.net/                                    |
| --------------------------------------------------------------------------|
|  Authors: Fabio Semperboni                                                |
|  Blog: http://www.ciscozine.com                                           |
|  Twitter: https://twitter.com/ciscozine                                   |
|  Copyright (c) 2012-2014, Fabio Semperboni                                |
| ------------------------------------------------------------------------- |
|  License: WhoisUP is released under the GPL                               |
|  This program is free software; you can redistribute it and/or modify     |
|  it under the terms of the GNU General Public License as published by     |
|  the Free Software Foundation; either version 2 of the License, or        |
|  (at your option) any later version.                                      |
|                                                                           |
|  This program is distributed in the hope that it will be useful,          |
|  but WITHOUT ANY WARRANTY; without even the implied warranty of           |
|  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            |
|  GNU General Public License for more details.                             |
|                                                                           |
|  You should have received a copy of the GNU General Public License        |
|  along with this program; if not, write to the Free Software              |
|  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA02110-1301  USA |
'---------------------------------------------------------------------------'
*/

$whoisup_title = '';
$secret_key = 'whoisup';
$threshold = '60'; //Minutes
$refresh_time = '30'; //Seconds
$cookie_time = '24'; //Hours

$latency_time = '150'; //Milliseconds

$nmap_folder = '';
$script_folder = '';

$timezone_select = 'Europe/Rome';

$maintenance_alert = false;
$popup_alert = false;
$sound_alert = false;
$syslog_alert = false;
$mail_alert = false;

$sound_file = 'Alarm.mp3';

$syslog_server = '';
$syslog_port = '514';
$syslog_facility = '14';
$syslog_severity = '3';

$mail_server = '';
$mail_port = '';
$mail_auth = false;
$mail_secure_protocol = '';
$mail_username = '';
$mail_password = base64_decode('');
$mail_from = '';
$mail_to = '';

$max_width = '900';
$host_up_number = '3';
$host_down_number = '3';

//Don't change these settings
$file_ip_list = 'iplist.txt';
$file_tmp_xml = 'ip_report_tmp.xml';
$file_tmp_html = 'ip_report_tmp.html';
$file_tmp_html_compact = 'ip_report_tmp_compact.html';
$sw_version = '0.3';

if (isset($timezone_select) && $timezone_select!=''){
	date_default_timezone_set($timezone_select);
}

?>