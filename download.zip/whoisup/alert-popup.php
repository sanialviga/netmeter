<?php
require("conf/config.php");
$handle = opendir($script_folder.'TMP/');
?>

<div id="Popup-date">
<?php
echo date("r");
?>
</div>

<?php
$list_down='<div id="Popup-list"><ul>';

$i=0;
while (false !== ($entry = readdir($handle))) {
	if ($entry != "." && $entry != ".."&& $entry != ".htaccess" && $entry != $file_tmp_html && $entry != $file_tmp_html_compact && $entry != $file_tmp_xml) {
		if (!file_exists($script_folder.'TMP/'.$entry)){
			$info_stat_host=array();
			$info_stat_host[0]=time();
			$info_stat_host[1]=time();
		}
		else{
			if (!$handle_file = fopen($script_folder.'TMP/'.$entry, "r")){
				exit("INDEX: Cannot open TMP/".$entry." file");
			}
			if (!$contents = fread($handle_file , filesize($script_folder.'TMP/'.$entry))){
				exit("INDEX: Cannot read TMP/".$entry." file");
			}
			fclose($handle_file);

			$info_stat_host=explode('|',$contents);
		}
		$list_down .='<li><span class="Popup_name_host">'.$info_stat_host[2].' ('.$entry.')</span> - '.date('d M Y H:i:s O',$info_stat_host[0]).' - Since '.round((time()-$info_stat_host[0])/60).' minutes</li>';
		$i++;
	}
}
$list_down.='<ul></div>';
closedir($handle);
if ($i>1){
	$hosts_down=$i.' hosts are';
}
else{
	$hosts_down=$i.' host is';
}
echo '<div id="Popup-txt">'.$hosts_down.' down</div>';
echo $list_down;
echo '<br /><div id="Popup-exit">Press \'ESC\' or <span id="click-here">click here</span> to close the popup</div>';

?>