<?php
require("conf/config.php");
require("classes/PHPMailer_5.2.1/class.phpmailer.php");

set_time_limit(0);

//Search ip ID
function searchForId($id, $array) {
   foreach ($array as $key => $val) {
       if ($val['ip'] === $id) {
           return $key;
       }
   }
   return null;
}

//Change status True & False for Jquery
function fix_true_false($value){
	if ($value){
		return 'true';
	}
	else{
		return 'false';
	}
}

//Send syslog message
function send_remote_syslog($ip, $hostname, $server, $port=514, $facility=14, $severity=3, $type) {

	$priority_value=$facility*8+$severity;
	
	if ($type=='down'){
		$syslog_msg = '<'.$priority_value.'> '. date('Y M j H:i:s ') . ': The host '.$hostname.' ('.$ip.') is down.';
	}
	else{
		$syslog_msg = '<'.$priority_value.'> '. date('Y M j H:i:s ') . ': The host '.$hostname.' ('.$ip.') is back up.';
	}
	
	if (!$sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP)){
		exit("Cannot create socket");
	}
	if (!socket_sendto($sock, $syslog_msg, strlen($syslog_msg), 0, $server, $port)){
		exit("Cannot send syslog message");
	}
	socket_close($sock);
	
}

//Send  multiple alert via mail
function send_mail($ip, $hostname, $first_down, $last_down, $latency) {
	$mail = new PHPMailer();

	$mail->IsSMTP();
	$mail->Host = $GLOBALS['mail_server'];
	$mail->SMTPAuth = $GLOBALS['mail_auth'];
	if ($GLOBALS['mail_auth']){
		$mail->Username = $GLOBALS['mail_username'];
		$mail->Password = $GLOBALS['mail_password'];
	}
	$mail->Port = $GLOBALS['mail_port'];
	$mail->SMTPSecure = $GLOBALS['mail_secure_protocol'];

	$mail->From = $GLOBALS['mail_from'];
	$mail->FromName = $GLOBALS['mail_from'];
	
	$mail->WordWrap = 200;
	$mail->IsHTML(false);
	
	if($first_down==0){
		$minutes_down=0;
	}
	else{
		$minutes_down=round(($last_down-$first_down)/60);
	}
	
	if ($latency=='-1'){
		$mail->Subject = "Host error: ". $hostname.' (' .$ip .') is down';
		$mail->Body    = "The hostname ".$hostname. ' (' . $ip .") is down.\n\n";
		$mail->Body    .= $hostname. ' (' . $ip .") downtime is ". $minutes_down . " minutes.\n";
		$mail->Body    .= "First down: ".date("r",$first_down)."\n";
		$mail->Body    .= "Last check: ".date("r",$last_down)."\n";
	}
	else{
		$mail->Subject = "Host notice: ". $hostname.' (' .$ip .') is up';
		$mail->Body    = "The hostname ".$hostname. ' (' . $ip .") is back up.\n\n";
		$mail->Body    .= "Host previously down for: ". $minutes_down ." minutes.\n";
		$mail->Body    .= "Last check: ".date("r",$last_down)."\n";
		$mail->Body    .= "Current ping response: ".$latency."ms\n";
	}
	
	$mail_to_list=explode(',', $GLOBALS['mail_to']);

	$mail_counter=0;
	while($mail_counter < count($mail_to_list)){
		$mail_new = clone $mail;
		$mail_new->AddAddress(str_replace(' ', '', $mail_to_list[$mail_counter]));
		$mail_new->Send();
		$mail_counter++;
	}

}

if (((isset($_GET['secret']) && $secret_key == $_GET['secret']) || (isset($argv) && $secret_key==$argv[1]))){

	if(($nmap_folder=='' || !is_dir($nmap_folder)) || ($script_folder=='' && !is_dir($script_folder))){
		exit ('Check your nmap or script absolute path');
	}

	$loop=true;
	echo 'Status: Running... ';
	while($loop){

		//Reloading variables
		require("conf/config.php");
		
		if (isset($argv)){
			$loop=true;
		}
		else{
			$loop=false;
		}

		unset($i, $contents, $entry, $html_tmp_compact, $xml_tmp, $info_stat_host, $host_down_array, $host_up_down_array);
		$i=0; $n_tot=0; $id=0; $sound_html=''; $latency=''; $tot_hosts=0; $tot_hosts_up=0; $tot_hosts_down=0; $html_hosts_tmp_up=''; $html_hosts_tmp_down=''; $html_tmp=''; $type_host_up=''; $tot_hosts_up_down=0;
		
		$hosts_info=array();
		$hosts_info_tmp=array();
		$hosts_name_tmp=array();
		$hosts_name=array();
		$hosts_ip=array();
		$hosts_latency=array();
		$info_stat_host=array();
		$list_ip=array();
		$host_down_array=array();
		$host_up_down_array=array();
		
		chdir($nmap_folder);

		//Only for advanced configuration
		exec("nmap -sn -n -v -PE --disable-arp-ping -iL \"".$script_folder."conf/".$file_ip_list."\" -oX \"".$script_folder."TMP/".$file_tmp_xml."\"");

		chdir($script_folder);
		chmod($script_folder."TMP/".$file_tmp_xml, 0666);

		$xml_tmp = simplexml_load_file($script_folder.'TMP/'.$file_tmp_xml);
		
		foreach($xml_tmp->host as $host){
			$hosts_info_tmp[$tot_hosts]['ip']=(string)$host->address['addr'];
			$hosts_info_tmp[$tot_hosts]['state']=(string)$host->status['state'];
			$hosts_info_tmp[$tot_hosts]['latency']=(string)$host->times['srtt'];
			$tot_hosts++;
		}
		
		if (!$handle = fopen($script_folder.'conf/'.$file_ip_list, "r")) {
			exit ("Cannot open file -r- conf/".$file_ip_list." file");
		}

		while (($buffer = fgets($handle)) !== false) {
			if (preg_match("/ # /", $buffer)){
				$hosts_name_tmp=explode(' # ', $buffer);
				$hosts_name[$n_tot]=@str_replace(array("\r", "\n"), "", (string)$hosts_name_tmp[1]);
				$hosts_ip[$n_tot]=@str_replace(array("\r", "\n"), "", (string)$hosts_name_tmp[0]);
				$hosts_latency[$n_tot]=@str_replace(array("\r", "\n"), "", (string)$hosts_name_tmp[2]);

				$id=searchForId($hosts_ip[$n_tot],$hosts_info_tmp);
				
				$hosts_info[$n_tot]['ip']=$hosts_info_tmp[$id]['ip'];
				$hosts_info[$n_tot]['state']=$hosts_info_tmp[$id]['state'];
				$hosts_info[$n_tot]['latency']=$hosts_info_tmp[$id]['latency'];

				if ($hosts_latency[$n_tot]==null){ $hosts_latency[$n_tot]=$latency_time; }
				$hosts_latency[$n_tot]=$hosts_latency[$n_tot];
				$n_tot++;
			}
		}
		if (!feof($handle)) {
			exit("Error: unexpected fgets() fail\n");
		}
		fclose($handle);
		
		$i=0;
		while($i<$n_tot){
			if (@$hosts_info[$i]['state']=='up'){
				if ($hosts_info[$i]['latency']==0){
					$latency='<1';
					$type_host_up='host_up';
				}
				else{
					$latency=round($hosts_info[$i]['latency']/1000,3);
					if ($latency>$hosts_latency[$i]){
						$type_host_up='host_up_down';
						$host_up_down_array[$tot_hosts_up_down]=array($hosts_name[$i], $hosts_ip[$i], $latency, $hosts_latency[$i]);
						$tot_hosts_up_down++;
					}
					else{
						$type_host_up='host_up';
					}
				}
				
				$html_hosts_tmp_up .=  '<div class="'.$type_host_up.'"><span class="name-host">Name: '.$hosts_name[$i].'<br /></span><span class="IP-host">IP: '.$hosts_ip[$i].'<br /></span><span class="latency-host">Now: '.$latency.'ms - Threshold '.$hosts_latency[$i].'ms<br /></span></div>';
				
				if (file_exists($script_folder.'TMP/'.$hosts_ip[$i])){
				
					$info_stat_host=array();

					if (!$handle = fopen($script_folder.'TMP/'.$hosts_ip[$i], "r")){
						exit("INDEX: Cannot open TMP/".$hosts_ip[$i]." file");
					}
					if (!$contents = fread($handle , filesize($script_folder.'TMP/'.$hosts_ip[$i]))){
						exit("INDEX: Cannot read TMP/".$hosts_ip[$i]." file");
					}
					fclose($handle);
					$info_stat_host=explode('|',$contents);
					
					if (!unlink($script_folder.'TMP/'.$hosts_ip[$i])){
						exit ("Cannot delete TMP/".$hosts_ip[$i]." file");
					}
					
					if (!$maintenance_alert){
						if ($syslog_alert){
							send_remote_syslog($hosts_ip[$i], $hosts_name[$i], $syslog_server, $syslog_port, $syslog_facility, $syslog_severity, 'up');
						}

						if ($mail_alert){
							send_mail($hosts_ip[$i], $hosts_name[$i], (int)$info_stat_host[0], time(), $latency);
						}
					}
					
				}
				
				$tot_hosts_up++;
			}
			else{
				$info_stat_host=array();
				$new_tmp_file=false;

				if (@filesize('TMP/'.$hosts_ip[$i])<=0){
				
					if (!$handle = fopen($script_folder.'TMP/'.$hosts_ip[$i], "w")){
						exit("Cannot open -w- TMP/".$hosts_ip[$i]." file");
					}
					if (!fwrite($handle,time().'|'.time().'|'.$hosts_name[$i])){
						exit("Cannot write TMP/".$hosts_ip[$i]." file");
					}
					fclose($handle);
					
					chmod($script_folder.'TMP/'.$hosts_ip[$i], 0666);
					$new_tmp_file=true;

				}

				if (!$handle = fopen($script_folder.'TMP/'.$hosts_ip[$i], "r")){
					exit("INDEX: Cannot open TMP/".$hosts_ip[$i]." file");
				}
				if (!$contents = fread($handle , filesize($script_folder.'TMP/'.$hosts_ip[$i]))){
					exit("INDEX: Cannot read TMP/".$hosts_ip[$i]." file");
				}
				fclose($handle);

				$info_stat_host=explode('|',$contents);

				if ($info_stat_host[1]<=(time()-$threshold*60) || $new_tmp_file){
					if (!$handle = fopen($script_folder.'TMP/'.$hosts_ip[$i], "w")){
						exit("Cannot open -w- TMP/".$hosts_ip[$i]." file");
					}
					if (!fwrite($handle,$info_stat_host[0].'|'.time().'|'.$hosts_name[$i])){
						exit("Cannot write TMP/".$hosts_ip[$i]." file");
					}
					fclose($handle);

					if (!$maintenance_alert){
						if ($syslog_alert){
							send_remote_syslog($hosts_ip[$i], $hosts_name[$i], $syslog_server, $syslog_port, $syslog_facility, $syslog_severity, 'down');
						}

						if ($mail_alert){
							send_mail($hosts_ip[$i], $hosts_name[$i], (int)$info_stat_host[0], time(), '-1');
						}

						$sound_html='<embed src="sound_alert/'.$sound_file.'" hidden="true" autostart="true" loop="false" type="audio/mpeg" />';
					}
				}
				
				$html_hosts_tmp_down .=  '<div class="host_down"><span class="name-host">Name: '.$hosts_name[$i].'<br /></span><span class="IP-host">IP: '.$hosts_ip[$i].'<br /></span><span class="latency-host">Fail: '.date('d M Y H:i:s O',$info_stat_host[0]).'<br /></span></div>';
				$host_down_array[$tot_hosts_down]=array($hosts_name[$i], $hosts_ip[$i], $info_stat_host[0]);
				$tot_hosts_down++;
			}
			$i++;
		}

		//For normal view
		$html_tmp = '<div id="header"><div id="title"><img src="images/title.png" alt="" /><div id="title_info">'.@$whoisup_title.'</div></div><div id="info"><div id="hosts_info"><span id="total_hosts">Total hosts: '.$n_tot.'</span><span id="n_up_hosts">Up: <span id="up">'.$tot_hosts_up.'</span></span><span id="n_down_hosts">Down: <span id="down">'.$tot_hosts_down.'</span></span></div><div id="scan_info">Scanning time: '.$xml_tmp->runstats->finished['elapsed'].' seconds</div><div id="update_info">Last update: '.date('H:i:s O').'</div></div></div>';
		$html_tmp .= '<div class="space-top"></div>';
		if ($tot_hosts_down!=0){
			$html_tmp .= '<div id="hosts_down_box"><div id="hosts_down_title">Hosts Down</div><div id="hosts_down">'.$html_hosts_tmp_down.'</div></div>';
		}
		$html_tmp .= '<div id="hosts_up_box"><div id="hosts_up_title">Hosts Up</div><div id="hosts_up">'.$html_hosts_tmp_up.'</div></div>';
		$html_tmp .= '<div class="space-bottom"></div>';
		$html_tmp .= '<div id="footer"><div id="links"><a href="?compact">Compact mode</a> - <a href="admin.php">Admin Page</a> - <a href="http://whoisup.sourceforge.net/" target="_blank">WhoisUP&copy;</a></div></div>';
		$html_tmp .= '<div id="value_tmp"><div id="popup_alert">'.fix_true_false($popup_alert).'</div><div id="maintenance_alert">'.fix_true_false($maintenance_alert).'</div></div>';
		if ($sound_alert && !$maintenance_alert){
			$html_tmp .= $sound_html;
		}
		
		//For compact view
		$html_tmp_compact = '<div id="header"><div id="title"><img src="images/title.png" alt="" /><div id="title_info">'.@$whoisup_title.'</div></div></div>';
		$html_tmp_compact .= '<div class="space-top"></div>';
		$html_tmp_compact .= '<div id="main"><div id="up_box" class="box"><span id="up_up">'.($tot_hosts_up-$tot_hosts_up_down).'</span><span class="host_desc">UP</span></div><div id="up_down_box" class="box"><span id="up_down">'.$tot_hosts_up_down.'</span><span class="host_desc">WARNING</span></div><div id="down_box" class="box"><span id="down">'.$tot_hosts_down.'</span><span class="host_desc">DOWN</span></div></div>';

		if ($popup_alert){
			if ($tot_hosts_down>0 && !$maintenance_alert){
				$html_tmp_compact .= '<div id="hosts_down"><span id="hosts_down_title">DOWN:</span><ul>';
			
				for ($j = 0; $j < $tot_hosts_down; $j++) {
					$html_tmp_compact .=  '<li class="hosts_down_desc"><span class="host_down">'.$host_down_array[$j][0].' ('.$host_down_array[$j][1].')</span> - <span class="host_down_date">'.date('d M Y H:i:s O', $host_down_array[$j][2]).' - Since '.round((time()-$host_down_array[$j][2])/60).' minutes</span></li>';
				}
				
				$html_tmp_compact .= '</ul></div>';
			}
			if ($tot_hosts_up_down>0){
				$html_tmp_compact .= '<div id="hosts_up_down"><span id="hosts_up_down_title">WARNING:</span><ul>';
				
				for ($j = 0; $j < $tot_hosts_up_down; $j++) {
					$html_tmp_compact .=  '<li class="hosts_up_down_desc"><span class="host_up_down">'.$host_up_down_array[$j][0].' ('.$host_up_down_array[$j][1].') - </span><span class="host_up_down_latency">Now '.$host_up_down_array[$j][2].'<span class="unit">ms</span> - Threshold '.$host_up_down_array[$j][3].'<span class="unit">ms</span></span></li>';
				}
				
				$html_tmp_compact .= '</ul></div>';
			}
		}
		$html_tmp_compact .= '<div class="space-bottom"></div>';
		$html_tmp_compact .= '<div id="footer"><div><span id="scan_info">Scanning time: '.$xml_tmp->runstats->finished['elapsed'].' seconds</span> - <span id="update_info">Last update: '.date('H:i:s O').'</span></div><div id="links"><a href="?normal">Normal mode</a> - <a href="admin.php">Admin Page</a> - <a href="http://whoisup.sourceforge.net/" target="_blank">WhoisUP&copy;</a></div></div>';
		$html_tmp_compact .= '<div id="value_tmp"><div id="popup_alert">'.fix_true_false($popup_alert).'</div><div id="maintenance_alert">'.fix_true_false($maintenance_alert).'</div><div id="up">'.$tot_hosts_up.'</div></div>';
		if ($sound_alert && !$maintenance_alert){
			$html_tmp_compact .= $sound_html;
		}

		
		//Saving the normal view output
		if (!$handle = fopen($script_folder.'TMP/'.$file_tmp_html, 'w')) {
			exit ("Cannot open TMP/".$file_tmp_html." file");
		}
		if (fwrite($handle, $html_tmp) === FALSE) {
			exit ("Cannot write TMP/".$file_tmp_html." file");
		}
		fclose($handle);
		chmod($script_folder.'TMP/'.$file_tmp_html, 0666);
		
		//Saving the compact view output
		if (!$handle = fopen($script_folder.'TMP/'.$file_tmp_html_compact, 'w')) {
			exit ("Cannot open TMP/".$file_tmp_html_compact." file");
		}
		if (fwrite($handle, $html_tmp_compact) === FALSE) {
			exit ("Cannot write TMP/".$file_tmp_html_compact." file");
		}
		fclose($handle);
		chmod($script_folder.'TMP/'.$file_tmp_html_compact, 0666);

		if ($loop){
			sleep($refresh_time);
		}
		
	}

	header('refresh:'.($refresh_time).';url=core.php?secret='.$secret_key);
	exit();
	
}
else{
	if (!isset($_GET['compact'])){
		if (!$handle = @fopen($script_folder.'TMP/'.$file_tmp_html, "r")){
			$contents = 'I can\'t open the '.$file_tmp_html.' file';
		}
		else{
			if (!$contents = @fread($handle , filesize($script_folder.'TMP/'.$file_tmp_html))){
				$contents = 'I can\'t read the '.$file_tmp_html.' file';
			}
			fclose($handle);
		}
		echo $contents;
	}
	else{
		if (!$handle_compact = fopen($script_folder.'TMP/'.$file_tmp_html_compact, "r")){
			$contents = 'I can\'t open the '.$file_tmp_html_compact.' file';
		}
		else{
			if (!$contents = @fread($handle_compact , filesize($script_folder.'TMP/'.$file_tmp_html_compact))){
				$contents = 'I can\'t read the '.$file_tmp_html_compact.' file';
			}
			fclose($handle_compact);
		}
		echo $contents;
	}

}
?>