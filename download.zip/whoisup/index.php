<?php require("conf/config.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="cache-control" content="no-cache" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />

<script src="js/jquery-latest.js" type="text/javascript"></script>
<script src="js/modal.popup.js" type="text/javascript"></script>
<?php
if (!isset($_GET['compact'])){
?>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<?php
}
else{
?>
<link href="css/style_compact.css" rel="stylesheet" type="text/css" />
<?php
}
?>
<meta name="generator" content="<?php echo $sw_version; ?>" />
<link rel="shortcut icon" href="images/favicon.ico" />

<title>WhoisUP [Loading...]</title>

<style type="text/css"> 
div.host_up{
	width: <?php $x = (($max_width-30)/$host_up_number)-16; echo (int)$x;?>px;
}
div.host_up_down{
	width: <?php $x = (($max_width-30)/$host_up_number)-16; echo (int)$x;?>px;
}
div.host_down{
	width: <?php $x = (($max_width-30)/$host_down_number)-16; echo (int)$x;?>px;
}
</style>


<script type="text/javascript">
//<![CDATA[//><!--
$(document).ready(function() {

	var refresh_time=1000;
	var view_popup=true;
	var time_tmp = -1;
	var check_whoisup = 0;
	
	var align = 'center';
	var top = 200;
	var width = 600;
	var padding = 10;
	var backgroundColor = '#FFFFFF';
	var source = 'alert-popup.php';
	var borderColor = '#333333';
	var borderWeight = 2;
	var borderRadius = 5;
	var fadeOutTime = 300;
	var disableColor = '#666666';
	var disableOpacity = 40;
	var loadingImage = 'images/loading-popup.gif';
	
	var title = 'Whoisup';

	
	var whoisup = function(){
		clearInterval(interval);
		interval = setInterval(whoisup, refresh_time);
		if ($("#title_info").text().length > 0 ){
			title = $("#title_info").html();
		}
		else{
			title = 'Whoisup';
		}
		
		<?php if (!isset($_GET['compact'])){
		?>
$("#container").load('core.php', function( response, status, xhr ){
		if ( status == "error" ) {
			$("#connection_problem").slideDown("slow");
		}
		else{
			$("#connection_problem").slideUp("slow");
		}

			$("#container").css("width","<?php echo $max_width;?>");
		<?php
		}
		else{
		?>
$("#container").load('core.php?compact', function( response, status, xhr ){
		if ( status == "error" ) {
			$("#connection_problem").slideDown("slow");
		}
		else{
			$("#connection_problem").slideUp("slow");
		}
			var name_box_compact = [$("#up_box").width(),$("#up_down_box").width(),$("#down_box").width()];
			var max_box_width;
			max_box_width = Math.max.apply( Math, name_box_compact );
			$(".box").css("width", max_box_width);
		<?php
		}
		?>
		
			if($("#maintenance_alert").html()=='true'){
				document.title = 'WhoisUP | You are in maintenance mode!';
				$("#maintenance").slideDown("slow");
			}
			else{
				$("#maintenance").slideUp("slow");
			}
			
			if (($("#down").html()==0 || $("#down").html()==null) || $("#maintenance_alert").html()=='true'){
				
				view_popup=true;
				
				if ($("#blockModalPopupDiv").css('display')=='block'){
					closePopup(fadeOutTime);
				}
			}
			else{
				<?php if (!isset($_GET['compact'])){?>
if($("#popup_alert").html()=='true'){				
					if (view_popup==true){
						if (($("#blockModalPopupDiv").length==0 || $("#blockModalPopupDiv").css('display')=='none')){
							modalPopup(align, top, width, padding, disableColor, disableOpacity, backgroundColor, borderColor, borderWeight, borderRadius, fadeOutTime, source, loadingImage);
						}
						else{
							$("#innerModalPopupDiv").load('alert-popup.php');
						}
					}
					
					$(document).keyup(function(e) {
						if (e.keyCode == 27) {
							view_popup=false;
							closePopup(fadeOutTime);
						}
					});
					
					$("#innerModalPopupDiv").click(function(){
						view_popup=false;
						closePopup(fadeOutTime);
					});
				}
				else{
					if($("#blockModalPopupDiv").length!=0){
						closePopup(fadeOutTime);
						view_popup=true;
					}
				}
				<?php } ?>
			}

			document.title = title + ' | Host up: ' + $("#up").html() + ' / Host down: ' + $("#down").html();
			
			if ($("#update_info").html()==time_tmp){
				check_whoisup += 1;
			}
			else{
				check_whoisup = 0;
				$("#script_down").slideUp("slow");
			}
			
			if (check_whoisup>=8){
				document.title = 'WhoisUP | Are you sure that core.php script is running?';
				$("#script_down").slideDown("slow");
				$('#update_info').css({"color": "red", "font-weight": "bold"});
			}
			time_tmp=$("#update_info").html();
			
		});	
		
		refresh_time = <?php echo ($refresh_time*1000)+1000; ?>;
	}
	
	var interval = setInterval(whoisup, refresh_time);
	$.ajaxSetup({ cache: false });
	
});
//--><!]]>
</script>

</head>
<body>

<div id="container"><img src="images/title.png" alt="" /><br /><br /><img src="images/ajax-loader.gif" alt="" /><br /><br />Loading...<br /></div>

<div id="script_down" style="display: none">Are you sure that the core.php script is running?</div>
<div id="maintenance" style="display: none">The script is in maintenance mode.<br />No alarms will be sent</div>
<div id="connection_problem" style="display: none">Connection problem.<br />Check your web server or your connection!</div>

</body>
</html>